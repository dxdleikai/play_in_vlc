To install the native application
  1. Open a terminal window and point it into this directory
  2. run ./install.sh

If you get "No such file or directory" message, it means the current directory is not the root of the extracted directory. Read http://add0n.com/open-in.html?#faq13 page for more info.

Installation Guide:
  https://www.youtube.com/watch?v=bB4Bj_APg4g
